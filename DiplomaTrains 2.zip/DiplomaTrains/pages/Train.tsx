import React, { useEffect, useState } from "react";
import { View, Text, FlatList, ActivityIndicator, StyleSheet, Image, TouchableOpacity, Linking, Pressable, Animated } from "react-native";

const Train = () => {
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showVideos, setShowVideos] = useState(false); // Контролируем видимость списка видео
  const scale1 = new Animated.Value(1);
  const scale2 = new Animated.Value(1);
  const scale3 = new Animated.Value(1);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await fetch(
          "https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=16&q=basketball%20training&key=AIzaSyDb1XCA9jsinUcN1ggy0jTDocWrujWOqQw"
        );
        const data = await response.json();
        setVideos(data.items);
      } catch (error) {
        console.error("Error fetching videos:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchVideos();
  }, []);

  const openYouTube = (videoId: string) => {
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    Linking.openURL(url).catch((err) => console.error("Couldn't open URL", err));
  };

  const handlePressIn = (scale: any) => {
    Animated.spring(scale, {
      toValue: 1.1,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = (scale: any) => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Workout Videos</Text>

      <View style={styles.cardContainer}>
        <Animated.View style={[styles.card, { transform: [{ scale: scale1 }] }]}> 
          <Pressable 
            onPressIn={() => handlePressIn(scale1)}
            onPressOut={() => handlePressOut(scale1)}
            style={styles.cardPressable}
          >
            <Text style={styles.cardText}>Beginner</Text>
          </Pressable>
        </Animated.View>

        <Animated.View style={[styles.card, { transform: [{ scale: scale2 }] }]}> 
          <Pressable 
            onPressIn={() => handlePressIn(scale2)}
            onPressOut={() => handlePressOut(scale2)}
            style={styles.cardPressable}
          >
            <Text style={styles.cardText}>Advanced</Text>
          </Pressable>
        </Animated.View>

        <Animated.View style={[styles.card, { transform: [{ scale: scale3 }] }]}> 
          <Pressable 
            onPressIn={() => handlePressIn(scale3)}
            onPressOut={() => handlePressOut(scale3)}
            onPress={() => setShowVideos(true)} // Устанавливаем состояние showVideos = true
            style={styles.cardPressable}
          >
            <Text style={styles.cardText}>Profi</Text>
          </Pressable>
        </Animated.View>
      </View>

      {/* Если showVideos = true, отображаем список видео */}
      {showVideos && (
        loading ? (
          <ActivityIndicator size="large" color="#E58E4E" />
        ) : (
          <FlatList
            data={videos}
            keyExtractor={(item) => item.id.videoId}
            numColumns={2}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => openYouTube(item.id.videoId)} style={styles.videoContainer}>
                <Image source={{ uri: item.snippet.thumbnails.medium.url }} style={styles.thumbnail} />
                <Text style={styles.title}>{item.snippet.title}</Text>
                <Text style={styles.channel}>{item.snippet.channelTitle}</Text>
              </TouchableOpacity>
            )}
          />
        )
      )}
    </View>
  );
};

export default Train;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
  },
  cardContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 100,
  },
  card: {
    width: 100,
    height: 100,
    borderRadius: 10,
    backgroundColor: "#f9f9f9",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  cardPressable: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  cardText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  videoContainer: {
    flex: 1,
    margin: 30,
    backgroundColor: "#f9f9f9",
    borderRadius: 10,
    padding: 30,
    alignItems: "center",
  },
  thumbnail: {
    width: "100%",
    height: 150,
    borderRadius: 10,
  },
  title: {
    marginTop: 8,
    fontSize: 14,
    fontWeight: "bold",
    textAlign: "center",
  },
  channel: {
    fontSize: 12,
    color: "gray",
    textAlign: "center",
  },
});