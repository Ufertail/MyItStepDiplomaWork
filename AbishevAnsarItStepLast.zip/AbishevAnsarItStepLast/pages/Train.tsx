import React, { useEffect, useState, useCallback } from "react";
import { 
  View, Text, FlatList, ActivityIndicator, StyleSheet, Image, 
  TouchableOpacity, Linking, Pressable, Animated, RefreshControl 
} from "react-native";
import { useAuth } from "../SignContext";

const Train = () => {
  const { userLevel } = useAuth();
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const scale = new Animated.Value(1);

  useEffect(() => {
    fetchVideos(`basketball training ${userLevel.toLowerCase()}`);
  }, [userLevel]);

  const fetchVideos = async (query: string) => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=16&q=${query}&key=AIzaSyDb1XCA9jsinUcN1ggy0jTDocWrujWOqQw`
      );
      const data = await response.json();
      setVideos(data.items);
    } catch (error) {
      console.error("Error fetching videos:", error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await fetchVideos(`basketball training ${userLevel.toLowerCase()}`);
    } finally {
      setRefreshing(false);
    }
  }, [userLevel]);

  const openYouTube = (videoId: string) => {
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    Linking.openURL(url).catch((err) => console.error("Couldn't open URL", err));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Workout Videos</Text>
      <Text style={styles.subHeader}>Level: {userLevel}</Text>

      {loading && !refreshing && (
        <ActivityIndicator size="large" color="#E58E4E" style={{ marginTop: 20 }} />
      )}

      <FlatList
        data={videos}
        keyExtractor={(item) => item.id.videoId}
        numColumns={2}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={["#E58E4E"]}
            tintColor="#E58E4E"
          />
        }
        renderItem={({ item }) => (
          <TouchableOpacity 
            onPress={() => openYouTube(item.id.videoId)} 
            style={styles.videoContainer}
          >
            <Image 
              source={{ uri: item.snippet.thumbnails.medium.url }} 
              style={styles.thumbnail} 
            />
            <Text style={styles.title}>{item.snippet.title}</Text>
            <Text style={styles.channel}>{item.snippet.channelTitle}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

export default Train;

const styles = StyleSheet.create({
  subHeader: {
    fontSize: 18,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
  },
  cardContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 100,
  },
  card: {
    width: 100,
    height: 100,
    borderRadius: 10,
    backgroundColor: "#f9f9f9",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  cardPressable: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  cardText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  videoContainer: {
    flex: 1,
    margin: 10,
    backgroundColor: "#f9f9f9",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
  },
  thumbnail: {
    width: "100%",
    height: 150,
    borderRadius: 10,
  },
  title: {
    marginTop: 8,
    fontSize: 14,
    fontWeight: "bold",
    textAlign: "center",
  },
  channel: {
    fontSize: 12,
    color: "gray",
    textAlign: "center",
  },
});
