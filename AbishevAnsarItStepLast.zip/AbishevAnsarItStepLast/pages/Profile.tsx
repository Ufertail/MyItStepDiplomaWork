import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Modal,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAuth } from "../SignContext";
import { useNavigation } from "@react-navigation/native";
import * as ImagePicker from "expo-image-picker";
import { MaterialIcons } from "@expo/vector-icons";

const ProfileScreen = ({ navigation }: any) => {
  const { user, logout, userLevel, setUserLevel } = useAuth();
  const [profileDescription, setProfileDescription] = useState<string | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [inputText, setInputText] = useState("");
  const [isLevelModalVisible, setIsLevelModalVisible] = useState(false);

  const levels = ['Beginner', 'Advanced', 'Profi'];

  useEffect(() => {
    const loadProfileData = async () => {
      const storedDescription = await AsyncStorage.getItem("profileDescription");
      const storedImage = await AsyncStorage.getItem("profileImage");
      if (storedDescription) {
        setProfileDescription(storedDescription);
        setInputText(storedDescription);
      }
      if (storedImage) setProfileImage(storedImage);
    };
    loadProfileData();
  }, []);

  const saveProfileDescription = async () => {
    await AsyncStorage.setItem("profileDescription", inputText);
    setProfileDescription(inputText);
    setIsEditing(false);
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setProfileImage(uri);
      await AsyncStorage.setItem("profileImage", uri);
    }
  };

  const handleLevelChange = (level: 'Beginner' | 'Advanced' | 'Profi') => {
    setUserLevel(level);
    setIsLevelModalVisible(false);
  };

  const handleLogout = () => {
    logout();
    navigation.navigate("Login");
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={pickImage}>
        {profileImage ? (
          <Image source={{ uri: profileImage }} style={styles.avatar} />
        ) : (
          <View style={styles.avatarPlaceholder}>
            <MaterialIcons name="person" size={50} color="gray" />
          </View>
        )}
      </TouchableOpacity>

      <Text style={styles.name}>{user || "Гость"}</Text>

      {isEditing ? (
        <TextInput
          style={styles.input}
          value={inputText}
          onChangeText={setInputText}
          onSubmitEditing={saveProfileDescription}
          autoFocus
        />
      ) : (
        <Text style={styles.description}>
          {profileDescription || "Описание профиля отсутствует"}
        </Text>
      )}

      <TouchableOpacity
        style={styles.editButton}
        onPress={() => (isEditing ? saveProfileDescription() : setIsEditing(true))}
      >
        <MaterialIcons name={isEditing ? "check" : "edit"} size={20} color="black" />
        <Text style={styles.editButtonText}>
          {isEditing ? "Сохранить" : "Изменить"}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={styles.levelButton}
        onPress={() => setIsLevelModalVisible(true)}
      >
        <Text style={styles.levelText}>Level: {userLevel}</Text>
        <MaterialIcons name="arrow-drop-down" size={24} color="black" />
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={isLevelModalVisible}
        onRequestClose={() => setIsLevelModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Your Level</Text>
            {levels.map((level) => (
              <TouchableOpacity
                key={level}
                style={[
                  styles.levelOption,
                  userLevel === level && styles.selectedLevel
                ]}
                onPress={() => handleLevelChange(level as 'Beginner' | 'Advanced' | 'Profi')}
              >
                <Text style={[
                  styles.levelOptionText,
                  userLevel === level && styles.selectedLevelText
                ]}>
                  {level}
                </Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setIsLevelModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <MaterialIcons name="logout" size={20} color="black" />
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
    backgroundColor: "#F5F5F5",
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 15,
    borderWidth: 2,
    borderColor: "#ddd",
  },
  avatarPlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "#E0E0E0",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },
  name: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: "gray",
    textAlign: "center",
    marginHorizontal: 20,
  },
  input: {
    fontSize: 16,
    textAlign: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#000",
    width: "80%",
    marginBottom: 10,
  },
  editButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 30,
    borderWidth: 1,
    borderColor: "#d1d1d1",
    marginTop: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
  },
  editButtonText: {
    fontSize: 16,
    color: "black",
    marginLeft: 8,
  },
  levelButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 30,
    borderWidth: 1,
    borderColor: '#d1d1d1',
    marginTop: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
  },
  levelText: {
    fontSize: 16,
    marginRight: 5,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 15,
    width: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  levelOption: {
    padding: 15,
    borderRadius: 10,
    marginVertical: 5,
    backgroundColor: '#f0f0f0',
  },
  selectedLevel: {
    backgroundColor: '#E58E4E',
  },
  levelOptionText: {
    fontSize: 16,
    textAlign: 'center',
  },
  selectedLevelText: {
    color: 'white',
  },
  closeButton: {
    marginTop: 20,
    padding: 15,
    backgroundColor: '#E58E4E',
    borderRadius: 10,
  },
  closeButtonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoutButton: {
    position: "absolute",
    bottom: 100,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 30,
    borderWidth: 1,
    borderColor: "#d1d1d1",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
  },
  logoutText: {
    fontSize: 16,
    color: "black",
    marginLeft: 8,
  },
});

export default ProfileScreen;