import React, { useEffect, useRef, useState } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, Animated } from "react-native";
import { useAuth } from "../SignContext";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface TrainingLog {
  id: string;
  date: string;
  duration: number;
  notes: string;
  exercises: string[];
}

const HomeScreen = ({navigation}: any) => {
  const { user } = useAuth();
  const [trainingLogs, setTrainingLogs] = useState<TrainingLog[]>([]);

  useEffect(() => {
    loadTrainingLogs();
  }, []);

  const loadTrainingLogs = async () => {
    try {
      const logs = await AsyncStorage.getItem("trainingLogs");
      if (logs) {
        setTrainingLogs(JSON.parse(logs));
      }
    } catch (error) {
      console.error("Error loading training logs:", error);
    }
  };

  const fadeAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 2500,
      useNativeDriver: true,
    }).start();
  }, []);

  return (
    <View style={styles.screen}>
      <Animated.Text style={[styles.greeting, { opacity: fadeAnim }]}>
        Hello, {user || "Guest"}! 👋
      </Animated.Text>
      
      <Text style={styles.sectionTitle}>Training Logs</Text>
      <FlatList
        data={trainingLogs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.logItem}>
            <Text style={styles.logDate}>{new Date(item.date).toLocaleDateString()}</Text>
            <Text style={styles.logDuration}>Duration: {item.duration} mins</Text>
            {item.exercises.length > 0 && (
              <View style={styles.exercisesList}>
                <Text style={styles.exercisesTitle}>Exercises:</Text>
                {item.exercises.map((exercise, index) => (
                  <Text key={index} style={styles.exerciseText}>• {exercise}</Text>
                ))}
              </View>
            )}
            {item.notes && <Text style={styles.logNotes}>{item.notes}</Text>}
          </View>
        )}
      />
    </View>
  );
};






 

export default HomeScreen;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  greeting: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginTop: 20,
    marginBottom: 10,
  },
  logItem: {
    backgroundColor: "#f9f9f9",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    width: "100%",
  },
  logDate: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },
  logDuration: {
    fontSize: 14,
    color: "#666",
    marginBottom: 5,
  },
  exercisesList: {
    marginTop: 5,
  },
  exercisesTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginBottom: 3,
  },
  exerciseText: {
    fontSize: 14,
    color: "#666",
    marginLeft: 10,
  },
  logNotes: {
    fontSize: 14,
    color: "#666",
    marginTop: 5,
    fontStyle: "italic",
  },
});
