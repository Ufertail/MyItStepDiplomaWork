import React, { useEffect, useState, useCallback } from "react";
import { 
  View, Text, FlatList, ActivityIndicator, StyleSheet, 
  TouchableOpacity, Linking, Modal, ScrollView,
  TextInput, Alert
} from "react-native";
import { useAuth } from "../SignContext";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { MaterialIcons } from "@expo/vector-icons";



interface TrainingLog {
  id: string;
  date: string;
  duration: number;
  notes: string;
  exercises: string[];
}

interface DailyPlan {
  title: string;
  exercises: {
    name: string;
    duration: string;
    description: string;
    completed: boolean;
  }[];
}

export default function Premium ({navigation}: any){
  const { userLevel } = useAuth();
  const [activeTab, setActiveTab] = useState<'plan' | 'videos' | 'log'>('plan');
  const [trainingLogs, setTrainingLogs] = useState<TrainingLog[]>([]);
  const [showNewLogModal, setShowNewLogModal] = useState(false);
  const [newLog, setNewLog] = useState({
    duration: '',
    notes: '',
    exercises: [] as string[]
  });
  const [currentExercise, setCurrentExercise] = useState('');
  const [dailyPlan, setDailyPlan] = useState<DailyPlan | null>(null);

  useEffect(() => {
    loadTrainingLogs();
    generateDailyPlan();
  }, [userLevel]);

  const loadTrainingLogs = async () => {
    try {
      const logs = await AsyncStorage.getItem('trainingLogs');
      if (logs) {
        setTrainingLogs(JSON.parse(logs));
      }
    } catch (error) {
      console.error('Error loading training logs:', error);
    }
  };

  const generateDailyPlan = () => {
    const plans: Record<string, DailyPlan> = {
      Beginner: {
        title: "Fundamentals Focus",
        exercises: [
          {
            name: "Dribbling Basics",
            duration: "15 mins",
            description: "Practice basic dribbling with both hands",
            completed: false
          },
          {
            name: "Shooting Form",
            duration: "20 mins",
            description: "Free throw line shots focusing on form",
            completed: false
          },
          {
            name: "Layup Practice",
            duration: "15 mins",
            description: "Right and left-hand layups",
            completed: false
          }
        ]
      },
      Advanced: {
        title: "Skill Enhancement",
        exercises: [
          {
            name: "Advanced Dribbling",
            duration: "20 mins",
            description: "Crossovers, behind the back, between legs",
            completed: false
          },
          {
            name: "Jump Shot Series",
            duration: "25 mins",
            description: "Mid-range and 3-point shooting",
            completed: false
          },
          {
            name: "Speed Drills",
            duration: "20 mins",
            description: "Sprints with ball handling",
            completed: false
          }
        ]
      },
      Profi: {
        title: "Elite Training",
        exercises: [
          {
            name: "Pro Dribbling Series",
            duration: "25 mins",
            description: "Complex dribbling combinations at game speed",
            completed: false
          },
          {
            name: "Advanced Shot Creation",
            duration: "30 mins",
            description: "Off-dribble shots, step-backs, fade-aways",
            completed: false
          },
          {
            name: "Explosive Movement",
            duration: "25 mins",
            description: "Quick change of direction with ball",
            completed: false
          }
        ]
      }
    };

    setDailyPlan(plans[userLevel]);
  };

  const toggleExerciseCompletion = async (index: number) => {
    if (!dailyPlan) return;

    const updatedPlan = { ...dailyPlan };
    updatedPlan.exercises[index].completed = !updatedPlan.exercises[index].completed;
    setDailyPlan(updatedPlan);

    if (updatedPlan.exercises.every(ex => ex.completed)) {
      Alert.alert(
        "Great Job! 🎉",
        "You've completed all exercises for today! Don't forget to log your training session.",
        [{ text: "OK", onPress: () => setShowNewLogModal(true) }]
      );
    }
  };

  const saveTrainingLog = async () => {
    if (!newLog.duration.trim()) {
      Alert.alert("Error", "Please enter training duration");
      return;
    }

    const log: TrainingLog = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      duration: parseInt(newLog.duration),
      notes: newLog.notes,
      exercises: newLog.exercises
    };

    const updatedLogs = [log, ...trainingLogs];
    setTrainingLogs(updatedLogs);
    await AsyncStorage.setItem('trainingLogs', JSON.stringify(updatedLogs));

    setNewLog({ duration: '', notes: '', exercises: [] });
    setShowNewLogModal(false);
  };

  const addExercise = () => {
    if (currentExercise.trim()) {
      setNewLog(prev => ({
        ...prev,
        exercises: [...prev.exercises, currentExercise.trim()]
      }));
      setCurrentExercise('');
    }
  };

  const renderDailyPlan = () => (
    <View style={styles.planContainer}>
      <Text style={styles.planTitle}>{dailyPlan?.title}</Text>
      {dailyPlan?.exercises.map((exercise, index) => (
        <TouchableOpacity 
          key={index}
          style={[styles.exerciseItem, exercise.completed && styles.completedExercise]}
          onPress={() => toggleExerciseCompletion(index)}
        >
          <View style={styles.exerciseHeader}>
            <Text style={styles.exerciseName}>{exercise.name}</Text>
            <Text style={styles.exerciseDuration}>{exercise.duration}</Text>
          </View>
          <Text style={styles.exerciseDescription}>{exercise.description}</Text>
          {exercise.completed && (
            <MaterialIcons name="check-circle" size={24} color="#4CAF50" style={styles.checkIcon} />
          )}
        </TouchableOpacity>
      ))}
    </View>
  );

  const renderTrainingLogs = () => (
    <View style={styles.logsContainer}>
      <TouchableOpacity 
        style={styles.addLogButton}
        onPress={() => setShowNewLogModal(true)}
      >
        <Text style={styles.addLogButtonText}>Add Training Log</Text>
      </TouchableOpacity>

      <FlatList
        data={trainingLogs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.logItem}>
            <Text style={styles.logDate}>
              {new Date(item.date).toLocaleDateString()}
            </Text>
            <Text style={styles.logDuration}>Duration: {item.duration} mins</Text>
            {item.exercises.length > 0 && (
              <View style={styles.exercisesList}>
                <Text style={styles.exercisesTitle}>Exercises:</Text>
                {item.exercises.map((exercise, index) => (
                  <Text key={index} style={styles.exerciseText}>• {exercise}</Text>
                ))}
              </View>
            )}
            {item.notes && <Text style={styles.logNotes}>{item.notes}</Text>}
          </View>
        )}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'plan' && styles.activeTab]}
          onPress={() => setActiveTab('plan')}
        >
          <Text style={[styles.tabText, activeTab === 'plan' && styles.activeTabText]}>
            Daily Plan
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'log' && styles.activeTab]}
          onPress={() => setActiveTab('log')}
        >
          <Text style={[styles.tabText, activeTab === 'log' && styles.activeTabText]}>
            Training Log
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'plan' && renderDailyPlan()}
      {activeTab === 'log' && renderTrainingLogs()}

      <Modal
        visible={showNewLogModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowNewLogModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Training Log</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Duration (minutes)"
              value={newLog.duration}
              onChangeText={(text) => setNewLog(prev => ({ ...prev, duration: text }))}
              keyboardType="numeric"
            />

            <View style={styles.exerciseInput}>
              <TextInput
                style={styles.exerciseInputField}
                placeholder="Add exercise"
                value={currentExercise}
                onChangeText={setCurrentExercise}
              />
            </View>

            {newLog.exercises.map((exercise, index) => (
              <View key={index} style={styles.exerciseTag}>
                <Text style={styles.exerciseTagText}>{exercise}</Text>
                <TouchableOpacity
                  onPress={() => {
                    setNewLog(prev => ({
                      ...prev,
                      exercises: prev.exercises.filter((_, i) => i !== index)
                    }));
                  }}
                >
                  <MaterialIcons name="close" size={18} color="#666" />
                </TouchableOpacity>
              </View>
            ))}

            <TextInput
              style={[styles.input, styles.notesInput]}
              placeholder="Notes"
              value={newLog.notes}
              onChangeText={(text) => setNewLog(prev => ({ ...prev, notes: text }))}
              multiline
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowNewLogModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, styles.saveButton]}
                onPress={saveTrainingLog}
              >
                <Text style={styles.modalButtonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16,
  },
  tabContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    borderRadius: 25,
    backgroundColor: '#f0f0f0',
    padding: 5,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 20,
  },
  activeTab: {
    backgroundColor: '#E58E4E',
  },
  tabText: {
    fontSize: 16,
    color: '#666',
  },
  activeTabText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  planContainer: {
    flex: 1,
  },
  planTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  exerciseItem: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#eee',
  },
  completedExercise: {
    backgroundColor: '#f0f7f0',
    borderColor: '#4CAF50',
  },
  exerciseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  exerciseName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  exerciseDuration: {
    fontSize: 14,
    color: '#666',
  },
  exerciseDescription: {
    fontSize: 14,
    color: '#666',
  },
  checkIcon: {
    position: 'absolute',
    right: 10,
    top: 10,
  },
  logsContainer: {
    flex: 1,
  },
  addLogButton: {
    backgroundColor: '#E58E4E',
    padding: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 20,
  },
  addLogButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  logItem: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  logDate: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  logDuration: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  exercisesList: {
    marginTop: 5,
  },
  exercisesTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 3,
  },
  exerciseText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 10,
  },
  logNotes: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
    fontStyle: 'italic',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  notesInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    margin: 20,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  cancelButton: {
    backgroundColor: '#ccc',
    padding: 12,
    borderRadius: 8,
    flex: 1,
    marginRight: 10,
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#E58E4E',
    padding: 12,
    borderRadius: 8,
    flex: 1,
    alignItems: 'center',
  },
  modalButton: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    flex: 1,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  exerciseInput: {
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
  },
  exerciseInputField: {
    height: 40,
    paddingHorizontal: 10,
  },
  exerciseTag: {
    backgroundColor: '#eee',
    padding: 8,
    borderRadius: 15,
    marginRight: 5,
    marginBottom: 5,
  },
  exerciseTagText: {
    fontSize: 14,
    color: '#333',
  },
});
