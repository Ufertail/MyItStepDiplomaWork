import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet } from 'react-native';
import React from 'react';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { Ionicons } from "@expo/vector-icons";

import HomeScreen from './pages/Home';
import Train from './pages/Train';
import Profile from './pages/Profile';
import Premium from './pages/Premium';

const Tab = createBottomTabNavigator();

export default function Component() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: styles.tabBar,
        tabBarShowLabel: false,
        headerShown: false,
      }}>
      <Tab.Screen 
        name="Home" 
        component={HomeScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <Ionicons name="home-outline" size={24} color={focused ? "#E58E4E" : "gray"} />
          ),
        }}
      />
      <Tab.Screen 
        name="Train" 
        component={Train}
        options={{
          tabBarIcon: ({ focused }) => (
            <FontAwesome6 name="dumbbell" size={24} color={focused ? "#E58E4E" : "gray"} />
          ),
        }} 
      />
      <Tab.Screen 
        name="Premium" 
        component={Premium} 
        options={{
          tabBarIcon: ({ focused }) => (
            <MaterialIcons name="workspace-premium" size={24} color={focused ? "#E58E4E" : "gray"} />
          ),
        }} 
      />
      <Tab.Screen 
        name="Profile" 
        component={Profile} 
        options={{
          tabBarIcon: ({ focused }) => (
            <Ionicons name="person-outline" size={24} color={focused ? "#E58E4E" : "gray"} />
          ),
        }} 
      />
    </Tab.Navigator>
  );
}

const CartScreen = () => (
  <View style={styles.screen}><Text>Sign up</Text></View>
);

const ProfileScreen = () => (
  <View style={styles.screen}><Text>Profile</Text></View>
);

const styles = StyleSheet.create({
  tabBar: {
    position: "absolute",
    bottom: 20,
    left: 20,
    right: 20,
    height: 70,
    borderRadius: 20,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    elevation: 5,
  },
  screen: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
