import React from "react";
import { StyleSheet } from "react-native";
import { Image, View } from "react-native-reanimated/lib/typescript/Animated";


export default function Card(){
    return(
        <View>
            <Image source={uri: ""} style={styles.Image} />
        </View>
    )
}

const styles = StyleSheet.create({
    Image: {
        width: "100%",
        height: "100%",
    }
})