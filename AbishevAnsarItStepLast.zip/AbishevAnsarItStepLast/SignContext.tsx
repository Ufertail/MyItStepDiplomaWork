import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

type UserLevel = 'Beginner' | 'Advanced' | 'Profi';

type AuthContextType = {
  user: string | null;
  userLevel: UserLevel;
  setUser: React.Dispatch<React.SetStateAction<string | null>>;
  login: (username: string) => void;
  logout: () => void;
  setUserLevel: (level: UserLevel) => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<string | null>(null);
  const [userLevel, setUserLevel] = useState<UserLevel>('Beginner');

  useEffect(() => {
    const loadUserData = async () => {
      const storedUser = await AsyncStorage.getItem('user');
      const storedLevel = await AsyncStorage.getItem('userLevel');
      
      if (storedUser) {
        setUser(storedUser);
      }
      if (storedLevel as UserLevel) {
        setUserLevel(storedLevel as UserLevel);
      }
    };
    loadUserData();
  }, []);

  const login = async (username: string) => {
    setUser(username);
    await AsyncStorage.setItem('user', username);
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem('user');
  };

  const updateUserLevel = async (level: UserLevel) => {
    setUserLevel(level);
    await AsyncStorage.setItem('userLevel', level);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      userLevel,
      setUser, 
      login, 
      logout,
      setUserLevel: updateUserLevel 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}