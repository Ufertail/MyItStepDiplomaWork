import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, Pressable } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "../SignContext";
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

import Component from "../Component";

const Tab = createBottomTabNavigator();



const CustomAddButton = ({ onPress }: { onPress: () => void }) => (
  <TouchableOpacity style={styles.addButton} onPress={onPress}>
    <Ionicons name="add" size={24} color="white" />
  </TouchableOpacity>
);

const HomeScreen = () => {
  const { user } = useAuth();
  
  return (
    <View style={styles.screen}>
      <Text style={styles.greeting}>Hello, {user || "Guest"}! 👋</Text>
      
    </View>
  );
};

const Home = ({ navigation }: any) => {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigation.replace("Login"); 
  };

  return (
    <Component></Component>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,  
    backgroundColor: '#fff',
  },
  screen: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  tabBar: {
    position: "absolute",
    bottom: 20,
    left: 20,
    right: 20,
    height: 70,
    borderRadius: 20,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    elevation: 5,
  },
  addButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#3D3D3D",
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    top: -25, 
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 5,
    elevation: 5,
  },
  greeting: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
});