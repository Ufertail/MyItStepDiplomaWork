import React, { useEffect, useState } from "react";
import { View, Text, FlatList, ActivityIndicator, StyleSheet } from "react-native";
import Video from "react-native-video";

const Tab = createBottomTabNavigator();


import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

import Component from "../Component";

const Train = ({navigation}: any) => {
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await fetch("6bf5ce7165msh36640a794a63dbdp1af361jsnce6da98c749c");
        const data = await response.json();
        setVideos(data.videos || []);
      } catch (error) {
        console.error("Error fetching videos:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchVideos();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Workout Videos</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#E58E4E" />
      ) : (
        <FlatList
          data={videos}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.videoContainer}>
              <Video
                source={{ uri: item.videoUrl }} 
                style={styles.video}
                controls
                resizeMode="cover"
              />
              <Text style={styles.title}>{item.title}</Text>
            </View>
          )}
        />
      )}

    <Component></Component>
      
    </View>
  );
};

export default Train;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
  },
  videoContainer: {
    marginBottom: 20,
  },
  video: {
    width: "100%",
    height: 200,
    borderRadius: 10,
  },
  title: {
    marginTop: 8,
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
});